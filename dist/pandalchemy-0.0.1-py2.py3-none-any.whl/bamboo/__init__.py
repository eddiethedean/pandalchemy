__version__ = '0.0.0'

from bamboo.bamboo_base import DataBase, Table